#!/bin/sh
cd /root/synopsys_custom/inv.starrc.lpe;  StarXtract_oa -clean /root/synopsys_custom/inv.starrc.lpe/star_herc_cmd.custom_compiler > /root/synopsys_custom/inv.starrc.lpe/stdout.lpe.log 2>&1
