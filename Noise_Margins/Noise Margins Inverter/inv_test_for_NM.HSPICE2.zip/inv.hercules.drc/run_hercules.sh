#!/bin/sh
cd /root/synopsys_custom/inv.hercules.drc; unset TCLLIBPATH; unset TCL_LIBRARY; exec-oa22.04.hercules hercules_oa -f openaccess -i baitap2904 -b inv -p . -O gdsii -o inv_result.gds /root/synopsys_custom/inv.hercules.drc/reference_drc.drc.evx > /root/synopsys_custom/inv.hercules.drc/stdout.drc.log 2>&1
