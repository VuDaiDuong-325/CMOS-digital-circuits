*Custom Compiler Version N-2017.12-SP1-2
*Tue May 12 01:09:29 2026

*.SCALE METER
*.LDD
.GLOBAL gnd! vdd!
********************************************************************************
* Library          : baitap2904
* Cell             : inv
* View             : schematic
* View Search List : auCdl schematic symbol
* View Stop List   : auCdl
********************************************************************************
.subckt inv in out
*.PININFO in:I out:O
MM1 out in vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM2 out in gnd! gnd! N w=1u l=0.1u nf=1 m=1
.ends inv


