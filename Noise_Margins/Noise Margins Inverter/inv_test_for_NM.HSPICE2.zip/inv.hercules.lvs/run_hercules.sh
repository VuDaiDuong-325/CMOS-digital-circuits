#!/bin/sh
cd /root/synopsys_custom/inv.hercules.lvs; unset TCLLIBPATH; unset TCL_LIBRARY; exec-oa22.04.hercules hercules_oa -f openaccess -i baitap2904 -b inv -p . -O gdsii -o inv_result.gds -s /root/synopsys_custom/inv.hercules.lvs/inv.custom_compiler.sp -sf CDL -stb inv /root/synopsys_custom/inv.hercules.lvs/reference_lvs.lvs.evx > /root/synopsys_custom/inv.hercules.lvs/stdout.lvs.log 2>&1
