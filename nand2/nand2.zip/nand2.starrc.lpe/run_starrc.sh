#!/bin/sh
cd /root/synopsys_custom/nand2.starrc.lpe;  StarXtract_oa -clean /root/synopsys_custom/nand2.starrc.lpe/star_herc_cmd.custom_compiler > /root/synopsys_custom/nand2.starrc.lpe/stdout.lpe.log 2>&1
