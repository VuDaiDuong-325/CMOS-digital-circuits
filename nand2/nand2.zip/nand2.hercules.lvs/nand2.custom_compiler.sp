*Custom Compiler Version N-2017.12-SP1-2
*Mon Jun  8 20:43:32 2026

*.SCALE METER
*.LDD
.GLOBAL gnd! vdd!
********************************************************************************
* Library          : baitap2904
* Cell             : nand2
* View             : schematic
* View Search List : auCdl schematic symbol
* View Stop List   : auCdl
********************************************************************************
.subckt nand2 A B Y
*.PININFO A:I B:I Y:O
MM1 Y B vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM0 Y A vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM3 net1 B gnd! gnd! N w=2u l=0.1u nf=1 m=1
MM2 Y A net1 gnd! N w=2u l=0.1u nf=1 m=1
.ends nand2


