#!/bin/sh
cd /root/synopsys_custom/nand2.hercules.drc; unset TCLLIBPATH; unset TCL_LIBRARY; exec-oa22.04.hercules hercules_oa -f openaccess -i baitap2904 -b nand2 -p . -O gdsii -o nand2_result.gds /root/synopsys_custom/nand2.hercules.drc/reference_drc.drc.evx > /root/synopsys_custom/nand2.hercules.drc/stdout.drc.log 2>&1
