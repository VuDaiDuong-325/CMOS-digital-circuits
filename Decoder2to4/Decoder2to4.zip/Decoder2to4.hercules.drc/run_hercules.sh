#!/bin/sh
cd /root/synopsys_custom/Decoder2to4.hercules.drc; unset TCLLIBPATH; unset TCL_LIBRARY; exec-oa22.04.hercules hercules_oa -f openaccess -i Decoder -b Decoder2to4 -p . -O gdsii -o Decoder2to4_result.gds /root/synopsys_custom/Decoder2to4.hercules.drc/reference_drc.drc.evx > /root/synopsys_custom/Decoder2to4.hercules.drc/stdout.drc.log 2>&1
