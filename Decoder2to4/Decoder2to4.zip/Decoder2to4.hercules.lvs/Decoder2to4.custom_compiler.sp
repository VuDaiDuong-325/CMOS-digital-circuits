*Custom Compiler Version N-2017.12-SP1-2
*Mon Jun  1 17:59:10 2026

*.SCALE METER
*.LDD
.GLOBAL gnd! vdd!
********************************************************************************
* Library          : baitap2904
* Cell             : inv
* View             : schematic
* View Search List : auCdl schematic symbol
* View Stop List   : auCdl
********************************************************************************
.subckt inv in out
*.PININFO in:I out:O
MM1 out in vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM2 out in gnd! gnd! N w=1u l=0.1u nf=1 m=1
.ends inv

********************************************************************************
* Library          : baitap2904
* Cell             : nand2
* View             : schematic
* View Search List : auCdl schematic symbol
* View Stop List   : auCdl
********************************************************************************
.subckt nand2 A B Y
*.PININFO A:I B:I Y:I
MM1 Y B vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM0 Y A vdd! vdd! P w=2.23u l=0.1u nf=1 m=1
MM3 net1 B gnd! gnd! N w=1u l=0.1u nf=1 m=1
MM2 Y A net1 gnd! N w=1u l=0.1u nf=1 m=1
.ends nand2

********************************************************************************
* Library          : Decoder
* Cell             : Decoder2to4
* View             : schematic
* View Search List : auCdl schematic symbol
* View Stop List   : auCdl
********************************************************************************
.subckt Decoder2to4 A0 A1 W0 W1 W2 W3
*.PININFO A0:I A1:I W0:O W1:O W2:O W3:O
XI7 net26 W3 inv
XI6 net23 W2 inv
XI5 net20 W1 inv
XI4 net17 W0 inv
XI3 net29 net32 inv
XI2 A0 net29 inv
XI1 net31 net28 inv
XI0 A1 net31 inv
XI11 net32 net28 net26 nand2
XI10 net29 net28 net23 nand2
XI9 net32 net31 net20 nand2
XI8 net29 net31 net17 nand2
.ends Decoder2to4


